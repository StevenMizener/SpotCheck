﻿********************************************************************************
	      TINY READ ME FILE FOR SPOTCHECK CONSOLE APPLICATION
********************************************************************************
Executable must be launched from a folder also containing the SpotCheckSDK DLL.

SUPPORTED COMMANDS IN THIS BUILD VERSION:

HelpMe
BatchSpot [batchfilepath] [optionalprecisionfactor] 
SoftSpot [sourcefilepath] [targetfilepath] [optionalprecisionfactor] 